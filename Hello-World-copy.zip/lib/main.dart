import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

import 'providers/market_provider.dart';

import 'screens/splash/splash_screen.dart';

import 'services/firebase_notification_service.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();

  // =========================
  // FIREBASE INIT
  // =========================

  await Firebase.initializeApp();

  // =========================
  // FIREBASE NOTIFICATION
  // =========================

  await FirebaseNotificationService
      .initialize();

  // =========================
  // GLOBAL ERROR HANDLER
  // =========================

  FlutterError.onError =

      (FlutterErrorDetails details) {

    FlutterError.presentError(
      details,
    );
  };

  runApp(
    const MyApp(),
  );
}

class MyApp extends StatelessWidget {

  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {

    return MultiProvider(

      providers: [

        ChangeNotifierProvider(

          create:
              (_) => MarketProvider(),
        ),
      ],

      child: MaterialApp(

        debugShowCheckedModeBanner:
            false,

        title: 'Option Analisis',

        // =========================
        // DARK THEME
        // =========================

        theme: ThemeData(

          brightness:
              Brightness.dark,

          scaffoldBackgroundColor:
              const Color(0xFF0D1117),

          primaryColor:
              Colors.blue,

          appBarTheme:
              const AppBarTheme(

            backgroundColor:
                Color(0xFF161B22),

            elevation: 0,

            centerTitle: true,

            titleTextStyle: TextStyle(

              color: Colors.white,

              fontSize: 20,

              fontWeight:
                  FontWeight.bold,
            ),
          ),

          cardColor:
              const Color(0xFF161B22),

          textTheme:
              const TextTheme(

            bodyMedium: TextStyle(
              color: Colors.white,
            ),
          ),

          elevatedButtonTheme:

              ElevatedButtonThemeData(

            style:
                ElevatedButton.styleFrom(

              backgroundColor:
                  Colors.blue,

              foregroundColor:
                  Colors.white,

              padding:
                  const EdgeInsets.symmetric(

                horizontal: 20,

                vertical: 14,
              ),

              shape:
                  RoundedRectangleBorder(

                borderRadius:
                    BorderRadius.circular(
                        14),
              ),
            ),
          ),
        ),

        // =========================
        // HOME SCREEN
        // =========================

        home:
            const SplashScreen(),
      ),
    );
  }
}